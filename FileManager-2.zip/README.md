# File Manager (مدير الملفات)
Kotlin + Jetpack Compose. Open this folder in Android Studio (Koala or newer), let Gradle sync, then Run.

- Files tab: browse internal storage + SD card, open / rename / copy / move / share / delete / new folder
- APK tab: scans the whole phone for .apk, shows icon/name/version, install one or many
- White light theme by default, dark mode toggle, Arabic/English with RTL/LTR (saved in DataStore)
- minSdk 24, targetSdk 34
- Launcher icon: adaptive vector (blue background + white folder) in res/drawable and res/mipmap-anydpi*

## GitHub Actions
- `.github/workflows/build.yml`   → builds a debug APK on every push (download from the run's Artifacts)
- `.github/workflows/release.yml` → on tag `v*`, builds signed APK + AAB (needs the 4 keystore secrets listed in the file)

No gradlew is bundled: the workflows install Gradle 8.7 themselves. Locally, run `gradle wrapper` once if you want gradlew.
