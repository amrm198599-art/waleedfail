package com.waleedmmh.filemanager

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun ApkScreen(t: Strings) {
    val ctx = LocalContext.current
    var apks by remember { mutableStateOf(emptyList<ApkInfo>()) }
    var loading by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf(setOf<String>()) }
    var queue by remember { mutableStateOf(emptyList<File>()) }

    // Installs one APK at a time; when the system installer returns, move on to the next.
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        queue = queue.drop(1)
    }
    LaunchedEffect(queue.firstOrNull()) {
        queue.firstOrNull()?.let { launcher.launch(Storage.installIntent(ctx, it, true)) }
    }
    LaunchedEffect(tick) {
        loading = true
        apks = withContext(Dispatchers.IO) { Storage.scanApks(ctx) }
        selected = emptySet()
        loading = false
    }

    fun start(list: List<File>) {
        if (list.isEmpty()) return
        if (!Storage.canInstall(ctx)) {
            Toast.makeText(ctx, t.allowInstall, Toast.LENGTH_LONG).show()
            Storage.askInstallPermission(ctx)
            return
        }
        queue = list
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(t.apkCount(apks.size), Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            if (apks.isNotEmpty()) {
                val all = selected.size == apks.size
                TextButton(onClick = {
                    selected = if (all) emptySet() else apks.map { it.file.absolutePath }.toSet()
                }) { Text(if (all) t.clear else t.selectAll) }
            }
            IconButton(onClick = { tick++ }) { Icon(Icons.Default.Refresh, t.refresh) }
        }
        HorizontalDivider()

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                loading -> Column(
                    Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CircularProgressIndicator()
                    Text(t.scanning, Modifier.padding(top = 16.dp))
                }
                apks.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(t.noApks)
                }
                else -> LazyColumn {
                    items(apks, key = { it.file.absolutePath }) { a ->
                        val key = a.file.absolutePath
                        val checked = key in selected
                        ListItem(
                            colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.background),
                            modifier = Modifier.clickable {
                                selected = if (checked) selected - key else selected + key
                            },
                            leadingContent = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = checked, onCheckedChange = {
                                        selected = if (it) selected + key else selected - key
                                    })
                                    if (a.icon != null) Image(a.icon, null, Modifier.size(40.dp))
                                    else Icon(
                                        Icons.Default.Android, null, Modifier.size(40.dp),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            },
                            headlineContent = { Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = {
                                Column {
                                    Text(
                                        "${t.version} ${a.version}  •  ${Storage.size(a.size)}",
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                    Text(
                                        a.file.name, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            },
                            trailingContent = {
                                TextButton(onClick = { start(listOf(a.file)) }) { Text(t.install) }
                            }
                        )
                    }
                }
            }
        }

        if (selected.isNotEmpty()) {
            Button(
                onClick = { start(apks.filter { it.file.absolutePath in selected }.map { it.file }) },
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            ) { Text(t.installSelected(selected.size)) }
        }
    }
}
