package com.waleedmmh.filemanager

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface Dlg {
    data class Rename(val f: File) : Dlg
    data class Delete(val f: File) : Dlg
    data object NewFolder : Dlg
}

private enum class Act { Open, Rename, Copy, Move, Share, Delete }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilesScreen(t: Strings) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val roots = remember { Storage.roots(ctx) }
    var path by rememberSaveable { mutableStateOf(roots[0].absolutePath) }
    var tick by remember { mutableIntStateOf(0) }
    var hidden by rememberSaveable { mutableStateOf(false) }
    var entries by remember { mutableStateOf(emptyList<File>()) }
    var clip by remember { mutableStateOf(emptyList<File>()) }
    var cut by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf<Dlg?>(null) }
    val root = roots.firstOrNull { path.startsWith(it.absolutePath) } ?: roots[0]
    val atRoot = path == root.absolutePath

    LaunchedEffect(path, tick, hidden) {
        entries = withContext(Dispatchers.IO) { Storage.list(File(path), hidden) }
    }
    BackHandler(enabled = !atRoot) { path = File(path).parent ?: root.absolutePath }

    fun work(block: () -> Boolean) {
        scope.launch {
            val ok = withContext(Dispatchers.IO) { runCatching(block).getOrDefault(false) }
            if (!ok) Toast.makeText(ctx, t.failed, Toast.LENGTH_SHORT).show()
            tick++
        }
    }

    fun paste() {
        val src = clip
        val isCut = cut
        val d = File(path)
        clip = emptyList()
        work {
            src.all { f ->
                val target = Storage.unique(File(d, f.name))
                when {
                    isCut && f.parentFile?.absolutePath == d.absolutePath -> true
                    target.absolutePath.startsWith(f.absolutePath + "/") -> false
                    isCut -> f.renameTo(target) || (f.copyRecursively(target) && f.deleteRecursively())
                    else -> f.copyRecursively(target)
                }
            }
        }
    }

    fun act(f: File, a: Act) {
        when (a) {
            Act.Open -> {
                if (f.isDirectory) {
                    path = f.absolutePath
                } else {
                    Storage.open(ctx, f, t)
                }
            }
            Act.Rename -> dialog = Dlg.Rename(f)
            Act.Copy -> { clip = listOf(f); cut = false }
            Act.Move -> { clip = listOf(f); cut = true }
            Act.Share -> Storage.share(ctx, f)
            Act.Delete -> dialog = Dlg.Delete(f)
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            if (roots.size > 1) {
                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    roots.forEachIndexed { i, r ->
                        FilterChip(
                            selected = r == root,
                            onClick = { path = r.absolutePath },
                            label = {
                                Text(
                                    if (i == 0) t.internal
                                    else t.sdCard + if (roots.size > 2) " $i" else ""
                                )
                            }
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    enabled = !atRoot,
                    onClick = { path = File(path).parent ?: root.absolutePath }
                ) { Icon(Icons.Default.ArrowUpward, null) }
                Text(
                    path.removePrefix(root.absolutePath).ifEmpty { "/" },
                    modifier = Modifier.weight(1f),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = LocalTextStyle.current.copy(textDirection = TextDirection.Ltr)
                )
                IconButton(onClick = { hidden = !hidden }) {
                    Icon(if (hidden) Icons.Default.Visibility else Icons.Default.VisibilityOff, t.showHidden)
                }
            }
            if (clip.isNotEmpty()) {
                Surface(color = MaterialTheme.colorScheme.secondaryContainer) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(t.clipLabel(clip.size, cut), Modifier.weight(1f))
                        TextButton(onClick = { paste() }) { Text(t.paste) }
                        TextButton(onClick = { clip = emptyList() }) { Text(t.cancel) }
                    }
                }
            }
            HorizontalDivider()
            if (entries.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text(t.emptyFolder) }
            } else {
                LazyColumn(contentPadding = PaddingValues(bottom = 88.dp)) {
                    items(entries, key = { it.absolutePath }) { f ->
                        FileRow(f, t) { a -> act(f, a) }
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { dialog = Dlg.NewFolder },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Icon(Icons.Default.CreateNewFolder, t.newFolder) }
    }

    when (val d = dialog) {
        is Dlg.Rename -> NameDialog(t.rename, d.f.name, t, { dialog = null }) { n ->
            dialog = null
            work { d.f.renameTo(File(d.f.parentFile, n)) }
        }
        Dlg.NewFolder -> NameDialog(t.newFolder, "", t, { dialog = null }) { n ->
            dialog = null
            work { File(File(path), n).mkdirs() }
        }
        is Dlg.Delete -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text(t.delete) },
            text = { Text(t.deleteConfirm(d.f.name)) },
            confirmButton = {
                TextButton(onClick = { dialog = null; work { d.f.deleteRecursively() } }) { Text(t.delete) }
            },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text(t.cancel) } }
        )
        null -> {}
    }
}

@Composable
private fun FileRow(f: File, t: Strings, onAction: (Act) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val amber = Color(0xFFF9A825)
    ListItem(
        colors = ListItemDefaults.colors(containerColor = MaterialTheme.colorScheme.background),
        modifier = Modifier.clickable { onAction(Act.Open) },
        leadingContent = {
            Icon(
                iconFor(f), null,
                tint = if (f.isDirectory) amber else MaterialTheme.colorScheme.primary
            )
        },
        headlineContent = { Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
        supportingContent = {
            Text(
                if (f.isDirectory) Storage.date(f) else Storage.size(f.length()) + "  •  " + Storage.date(f),
                style = MaterialTheme.typography.bodySmall
            )
        },
        trailingContent = {
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Default.MoreVert, null) }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    MenuEntry(t.open) { menu = false; onAction(Act.Open) }
                    MenuEntry(t.rename) { menu = false; onAction(Act.Rename) }
                    MenuEntry(t.copy) { menu = false; onAction(Act.Copy) }
                    MenuEntry(t.move) { menu = false; onAction(Act.Move) }
                    if (f.isFile) MenuEntry(t.share) { menu = false; onAction(Act.Share) }
                    MenuEntry(t.delete) { menu = false; onAction(Act.Delete) }
                }
            }
        }
    )
}

@Composable
private fun MenuEntry(label: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(label) }, onClick = onClick)
}

private fun iconFor(f: File): ImageVector {
    if (f.isDirectory) return Icons.Default.Folder
    return when (f.extension.lowercase()) {
        "apk" -> Icons.Default.Android
        "jpg", "jpeg", "png", "gif", "webp", "bmp" -> Icons.Default.Image
        "mp4", "mkv", "avi", "3gp", "mov" -> Icons.Default.Movie
        "mp3", "wav", "ogg", "m4a", "aac", "flac" -> Icons.Default.MusicNote
        "pdf", "txt", "doc", "docx", "xls", "xlsx", "ppt", "pptx" -> Icons.Default.Description
        else -> Icons.Default.InsertDriveFile
    }
}

@Composable
private fun NameDialog(
    title: String,
    initial: String,
    t: Strings,
    onDismiss: () -> Unit,
    onOk: (String) -> Unit
) {
    var text by remember { mutableStateOf(initial) }
    val valid = text.isNotBlank() && !text.contains('/')
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it },
                singleLine = true, label = { Text(t.name) }
            )
        },
        confirmButton = { TextButton(enabled = valid, onClick = { onOk(text.trim()) }) { Text(t.ok) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(t.cancel) } }
    )
}
