package com.waleedmmh.filemanager

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.preferencesDataStore

val Context.dataStore by preferencesDataStore(name = "settings")

object Keys {
    val DARK = booleanPreferencesKey("dark")
    val AR = booleanPreferencesKey("ar")
}
