package com.waleedmmh.filemanager

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ApkInfo(
    val file: File,
    val label: String,
    val version: String,
    val pkg: String,
    val size: Long,
    val icon: ImageBitmap?
)

object Storage {

    fun hasAccess(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) Environment.isExternalStorageManager()
        else ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED

    /** Internal storage first, then any SD card / USB volumes. */
    fun roots(ctx: Context): List<File> {
        val list = mutableListOf(Environment.getExternalStorageDirectory())
        ctx.getExternalFilesDirs(null).filterNotNull().forEach { d ->
            val i = d.absolutePath.indexOf("/Android/data")
            if (i > 0) {
                val r = File(d.absolutePath.substring(0, i))
                if (r.exists() && list.none { it.absolutePath == r.absolutePath }) list.add(r)
            }
        }
        return list
    }

    fun list(dir: File, showHidden: Boolean): List<File> =
        (dir.listFiles()?.toList() ?: emptyList())
            .filter { showHidden || !it.name.startsWith(".") }
            .sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))

    fun unique(target: File): File {
        if (!target.exists()) return target
        val base = target.nameWithoutExtension
        val ext = if (target.extension.isEmpty()) "" else "." + target.extension
        var i = 1
        while (true) {
            val c = File(target.parentFile, "$base ($i)$ext")
            if (!c.exists()) return c
            i++
        }
    }

    fun size(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        var v = bytes / 1024.0
        var i = 0
        while (v >= 1024 && i < units.lastIndex) { v /= 1024; i++ }
        return String.format(Locale.US, "%.1f %s", v, units[i])
    }

    fun date(f: File): String =
        SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(f.lastModified()))

    fun mime(f: File): String =
        MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"

    private fun uriFor(ctx: Context, f: File): Uri =
        FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)

    // ---------- install ----------
    fun canInstall(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O || ctx.packageManager.canRequestPackageInstalls()

    fun askInstallPermission(ctx: Context) {
        ctx.startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
        )
    }

    @Suppress("DEPRECATION")
    fun installIntent(ctx: Context, f: File, forResult: Boolean): Intent =
        Intent(Intent.ACTION_INSTALL_PACKAGE).apply {
            data = uriFor(ctx, f)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra(Intent.EXTRA_RETURN_RESULT, forResult)
        }

    // ---------- open / share ----------
    fun open(ctx: Context, f: File, t: Strings) {
        if (f.extension.equals("apk", true)) {
            if (!canInstall(ctx)) {
                Toast.makeText(ctx, t.allowInstall, Toast.LENGTH_LONG).show()
                askInstallPermission(ctx)
            } else ctx.startActivity(installIntent(ctx, f, false))
            return
        }
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uriFor(ctx, f), mime(f))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { ctx.startActivity(i) } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, t.noApp, Toast.LENGTH_SHORT).show()
        }
    }

    fun share(ctx: Context, f: File) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = mime(f)
            putExtra(Intent.EXTRA_STREAM, uriFor(ctx, f))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, null))
    }

    // ---------- APK scan ----------
    fun scanApks(ctx: Context): List<ApkInfo> {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val out = mutableListOf<ApkInfo>()
        for (r in roots(ctx)) {
            r.walkTopDown()
                .onEnter { d ->
                    val inAndroid = d.parentFile?.name == "Android"
                    !(inAndroid && (d.name == "data" || d.name == "obb"))
                }
                .forEach { f ->
                    if (f.isFile && f.extension.equals("apk", true) && seen.add(f.absolutePath)) {
                        val path = f.absolutePath
                        val info = runCatching { pm.getPackageArchiveInfo(path, 0) }.getOrNull()
                        val app = info?.applicationInfo?.also {
                            it.sourceDir = path
                            it.publicSourceDir = path
                        }
                        out += ApkInfo(
                            file = f,
                            label = runCatching { app?.loadLabel(pm)?.toString() }.getOrNull()
                                ?: f.nameWithoutExtension,
                            version = info?.versionName ?: "?",
                            pkg = info?.packageName ?: "",
                            size = f.length(),
                            icon = runCatching { app?.loadIcon(pm)?.toBitmap(96, 96)?.asImageBitmap() }.getOrNull()
                        )
                    }
                }
        }
        return out.sortedBy { it.label.lowercase() }
    }
}
