package com.waleedmmh.filemanager

class Strings(val ar: Boolean) {
    private fun s(en: String, a: String) = if (ar) a else en

    val appName = s("File Manager", "مدير الملفات")
    val files = s("Files", "الملفات")
    val apk = "APK"
    val permTitle = s("Storage access needed", "مطلوب إذن الوصول للملفات")
    val permBody = s(
        "To browse all files and folders on your phone, allow access to all files.",
        "لعرض كل ملفات ومجلدات الهاتف، اسمح للتطبيق بالوصول لكل الملفات."
    )
    val grant = s("Grant access", "منح الإذن")
    val internal = s("Internal storage", "الذاكرة الداخلية")
    val sdCard = s("SD card", "كارت الذاكرة")
    val open = s("Open", "فتح")
    val rename = s("Rename", "إعادة تسمية")
    val copy = s("Copy", "نسخ")
    val move = s("Move", "نقل")
    val share = s("Share", "مشاركة")
    val delete = s("Delete", "حذف")
    val cancel = s("Cancel", "إلغاء")
    val ok = s("OK", "موافق")
    val paste = s("Paste here", "لصق هنا")
    val newFolder = s("New folder", "مجلد جديد")
    val name = s("Name", "الاسم")
    val emptyFolder = s("This folder is empty", "المجلد فاضي")
    fun deleteConfirm(n: String) = s("Delete \"$n\"? This can't be undone.", "حذف \"$n\"؟ لا يمكن التراجع.")
    val failed = s("Operation failed", "فشلت العملية")
    val noApp = s("No app can open this file", "لا يوجد تطبيق لفتح هذا الملف")
    val allowInstall = s("Allow installing apps from this app, then try again", "اسمح للتطبيق بتثبيت التطبيقات ثم حاول مرة أخرى")
    val install = s("Install", "تثبيت")
    fun installSelected(n: Int) = s("Install selected ($n)", "تثبيت المحدد ($n)")
    val noApks = s("No APK files found", "لا توجد ملفات APK")
    val scanning = s("Scanning phone for APK files…", "جاري البحث عن ملفات APK…")
    val selectAll = s("Select all", "تحديد الكل")
    val clear = s("Clear", "إلغاء التحديد")
    val refresh = s("Refresh", "تحديث")
    val showHidden = s("Show hidden files", "إظهار الملفات المخفية")
    fun apkCount(n: Int) = s("$n APK files", "$n ملف APK")
    fun clipLabel(n: Int, cut: Boolean) =
        if (cut) s("$n to move", "$n للنقل") else s("$n to copy", "$n للنسخ")
    val version = s("Version", "الإصدار")
}
