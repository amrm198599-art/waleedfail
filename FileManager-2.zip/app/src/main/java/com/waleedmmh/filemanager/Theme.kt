package com.waleedmmh.filemanager

import android.app.Activity
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColors = lightColorScheme(
    primary = Color(0xFF1565C0),
    onPrimary = Color.White,
    background = Color.White,
    onBackground = Color(0xFF1B1B1F),
    surface = Color.White,
    onSurface = Color(0xFF1B1B1F),
    surfaceVariant = Color(0xFFF1F3F8),
    secondaryContainer = Color(0xFFDDE7F7),
    onSecondaryContainer = Color(0xFF0D2B52)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF90CAF9),
    onPrimary = Color(0xFF0B1F36),
    background = Color(0xFF0F1115),
    onBackground = Color(0xFFE4E6EB),
    surface = Color(0xFF0F1115),
    onSurface = Color(0xFFE4E6EB),
    surfaceVariant = Color(0xFF1B1F27),
    secondaryContainer = Color(0xFF263347),
    onSecondaryContainer = Color(0xFFDDE7F7)
)

@Composable
fun AppTheme(dark: Boolean, content: @Composable () -> Unit) {
    val view = LocalView.current
    SideEffect {
        val w = (view.context as? Activity)?.window ?: return@SideEffect
        WindowCompat.getInsetsController(w, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(colorScheme = if (dark) DarkColors else LightColors, content = content)
}
